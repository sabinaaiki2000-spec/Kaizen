import React, { useState } from 'react';
import { WorkbookGenerator } from './components/WorkbookGenerator';
import { WorkbookDisplay } from './components/WorkbookDisplay';
import { generateWorkbook } from './services/geminiService';
import { WorkbookData, AppState } from './types';
import { AlertCircle } from 'lucide-react';

export default function App() {
  const [appState, setAppState] = useState<AppState>(AppState.IDLE);
  const [workbookData, setWorkbookData] = useState<WorkbookData | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async (topic: string) => {
    setAppState(AppState.GENERATING);
    setError(null);
    try {
      const data = await generateWorkbook(topic);
      setWorkbookData(data);
      setAppState(AppState.VIEWING);
    } catch (err) {
      console.error(err);
      setError("Failed to generate workbook. Please check your API key or try again.");
      setAppState(AppState.ERROR);
    }
  };

  const handleReset = () => {
    setAppState(AppState.IDLE);
    setWorkbookData(null);
    setError(null);
  };

  if (appState === AppState.ERROR) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
        <div className="bg-white p-8 rounded-2xl shadow-lg max-w-md w-full text-center">
          <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <AlertCircle className="w-6 h-6 text-red-600" />
          </div>
          <h2 className="text-xl font-bold text-slate-900 mb-2">Oops! Something went wrong</h2>
          <p className="text-slate-600 mb-6">{error}</p>
          <button 
            onClick={handleReset}
            className="w-full bg-slate-900 text-white py-3 rounded-xl font-medium hover:bg-slate-800 transition-colors"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  if (appState === AppState.VIEWING && workbookData) {
    return <WorkbookDisplay data={workbookData} onReset={handleReset} />;
  }

  return (
    <WorkbookGenerator 
      onGenerate={handleGenerate} 
      isGenerating={appState === AppState.GENERATING} 
    />
  );
}
