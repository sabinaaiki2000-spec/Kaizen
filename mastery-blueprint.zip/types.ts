export interface GoalSettingSection {
  big_goals: string;
  milestones: string;
  thirty_day_objectives: string; // Mapped from '30_day_objectives'
}

export interface MonthlyPlanner {
  overview_page: string;
  habit_list_templates: string;
}

export interface WeeklyPlanner {
  week_template: string;
  habit_tracker: string;
  weekly_reflection: string;
}

export interface DailyPages {
  morning_prompt: string;
  evening_prompt: string;
  habit_checklist: string;
  motivation_quotes: string[];
}

export interface Challenges {
  seven_day_challenge: string; // Mapped from '7_day_challenge'
  twenty_one_day_challenge: string; // Mapped from '21_day_challenge'
}

export interface ReviewSection {
  progress_summary: string;
  reward_system: string;
}

export interface WorkbookData {
  WorkbookTitle: string;
  Introduction: string;
  HowToUse: string;
  GoalSettingSection: GoalSettingSection;
  MonthlyPlanner: MonthlyPlanner;
  WeeklyPlanner: WeeklyPlanner;
  DailyPages: DailyPages;
  Challenges: Challenges;
  ReviewSection: ReviewSection;
}

export enum AppState {
  IDLE = 'IDLE',
  GENERATING = 'GENERATING',
  VIEWING = 'VIEWING',
  ERROR = 'ERROR'
}

// For tracking user progress locally
export interface DailyEntry {
  date: string;
  morningReflection: string;
  eveningReflection: string;
  habitsChecked: boolean[]; // Simple boolean array for now
}

export interface UserProgress {
  entries: Record<string, DailyEntry>;
  goalNotes: string;
  checkedItems: Record<string, boolean>; // Tracks completion of list items (activities, milestones, etc.)
}